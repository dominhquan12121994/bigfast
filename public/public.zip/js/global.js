/*
 * Copyright (c) 2020. Electric
 */

$('.frm-select2').select2();

// $('[data-toggle="tooltip"]').tooltip();